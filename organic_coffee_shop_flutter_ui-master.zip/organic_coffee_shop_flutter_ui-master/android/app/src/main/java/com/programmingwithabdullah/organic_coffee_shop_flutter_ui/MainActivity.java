package com.programmingwithabdullah.organic_coffee_shop_flutter_ui;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
